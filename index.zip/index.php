<!DOCTYPE html>
<html>
<body>

<h1>My test  web site app1</h1>

<?php
echo "Hello World! VERSION1 ";
?>

</body>
</html>